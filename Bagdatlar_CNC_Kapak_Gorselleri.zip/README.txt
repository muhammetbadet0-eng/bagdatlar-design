Bağdatlar Design — CNC Kapak Üretimi görselleri

Bu klasörde BD-01.jpg ile BD-10.jpg arasında 10 model görseli bulunur.
GitHub deposunda index.html dosyasının bulunduğu ana dizine images klasörünü yükleyin.
Dosyaların yolu şu şekilde olmalıdır: images/cnc/bd-01.jpg ... images/cnc/bd-10.jpg

Görseller 1024 x 1536 piksel boyutlarında JPEG olarak optimize edilmiştir.
